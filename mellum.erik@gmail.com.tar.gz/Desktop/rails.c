#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
  int rails;
  char buffer[5000];
  char tester[5000];
  int* test = (int*)malloc(5000);
  scanf("%d", &rails);
  scanf(" ");
  printf("STRING: %s", buffer);
  for(int i=0; i<5000; i++)
  {
    tester[i]=
  }
}
